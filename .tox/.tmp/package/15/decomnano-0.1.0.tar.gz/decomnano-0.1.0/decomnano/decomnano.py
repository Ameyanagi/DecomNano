"""Main module."""

from wolframclient.evaluation import WolframLanguageSession
from wolframclient.language import wl, wlexpr
import re
import pandas as pd
import numpy as np
import os


class DecomNano(object):
    r"""DecomNano class for solving the heterogeneity analysis of bimetallic nanoparticles using coordination numbers obtained from XAS analysis.

    Attributes:
        session (WolframLanguageSession): Wolfram Language session
        input (dict): Input dictionary for the heterogeneity analysis
        results (pd.DataFrame): Results of the heterogeneity analysis
        column (list): Column names of the results
        dict_regex (re.compile): Regular expression for converting the results to a dictionary

    Todo:
        * Complete the docstring

    Note:
        * The variables in the input dictionary different from the paper due to the rules of python variable names.

        Sample Average
        n_(A-A): Total first ¬nearest neighbor coordination number of Au-Au bonds.
        n_(P-P): Total first ¬nearest neighbor coordination number of Pt-Pt bonds.
        n_(A-P): Total first ¬nearest neighbor coordination number of Au-Pt bonds.
        n_(P-A): Total first ¬nearest neighbor coordination number of Pt-Au bonds.

        Au NP
        X_A : The molar ratio of Au nanoparticles in the sample.
        N_A: The number of atoms in Au nanoparticles.
        n_(A-A,A) : First nearest neighbor coordination number of Au-Au bonds in Au nanoparticles.

        PtAu NP
        X_AP : The molar ratio of PtAu nanoparticles in the sample.
        N_AP : The number of atoms in PtAu nanoparticles.
        y : The molar fraction of Au in PtAu nanoparticles.
        n_(A-A,AP)  : First ¬nearest neighbor coordination number of Au-Au bonds for PtAu nanoparticles.
        n_(A-P,AP)   : First ¬nearest neighbor coordination number of Au-Pt bonds for PtAu nanoparticles.
        n_(P-A,AP)  : First ¬nearest neighbor coordination number of Pt-Au bonds for PtAu nanoparticles.
        n_(P-P,AP)  : First ¬nearest neighbor coordination number of Pt-Pt bonds for PtAu nanoparticles.
        n_(M-M,AP) : First ¬nearest neighbor coordination number of metal-metal bonds for PtAu nanoparticles.
        n_(A-M,AP)  : First ¬nearest neighbor coordination number of Au-metal bonds for PtAu nanoparticles.
        n_(P-M,AP) : First ¬nearest neighbor coordination number of Pt-metal bonds for PtAu nanoparticles.

        Pt NP
        X_P : The molar ratio of Pt nanoparticles in the sample.
        N_P: The number of atoms in Pt nanoparticles.
        n_(P-P,P): First nearest neighbor coordination number of Pt-Pt bonds in Pt nanoparticles


        +------------------------+------------+--------------+
        | Notation in paper      | Variables  | discriptions |
        +========================+============+==============+
        |                        | column 2   | column 3     |
        +------------------------+------------+--------------+
        | body row 2             | Cells may                 |
        +------------------------+------------+--------------+
        | body row 3             | Cells may  | - Table      |
        +------------------------+ span rows. | - conta      |
        | body row 4             |            | - body s.    |
        +------------------------+------------+--------------+
        | body row 5             | Cells may also be         |
        |                        | empty: ``-->``            |
        +------------------------+---------------------------+
    """

    def __init__(self, *args):
        super(DecomNano, self).__init__(*args)

        self.session = WolframLanguageSession()
        # self.session.evaluate(wlexpr(self.header_equation))
        self.session.evaluate(wl.Get("./DecomNano.wl"))
        self.results = pd.DataFrame()
        self.dict_regex = re.compile(r"Rule\[Global`(.*?), (.*?)]")

        self.column = [
            "dP",
            "dA",
            "fA",
            "nAA",
            "nPP",
            "nAP",
            "nPA",
            "DA",
            "DAP",
            "DP",
            "nAM_AP",
            "nPM_AP",
            "nAA_AP",
            "nAP_AP",
            "nPA_AP",
            "nPP_AP",
            "XAP",
            "XA",
            "XP",
            "y",
        ]

        self.input = dict(
            RPt=2.77,
            RAu=2.88,
            fAu=0.2,
            nAuAu=6.5,
            nPtPt=9.9,
            nAuPt=0.6,
            nPtAu=1.13,
            DA=0,
            DAP=18,
            DP=5,
        )

    def init_input(self, **kwargs):
        """Initialize the input dictionary of DecomNano class.

        Args:
            **kwargs: Keyword arguments for the input dictionary

        Examples:
            >>> dn = DecomNano()
            >>> dn.init_input(RPt=2.77, RAu=2.88, fAu=0.2, nAuAu=6.5, nPtPt=9.9, nAuPt=0.6, nPtAu=1.13, DA=0, DAP=18, DP=5)
        """
        self.input = dict(
            RPt=2.77,
            RAu=2.88,
            fAu=0.2,
            nAuAu=6.5,
            nPtPt=9.9,
            nAuPt=0.6,
            nPtAu=1.13,
            DA=0,
            DAP=18,
            DP=5,
        )

        self.input.update(kwargs)

    def calc_decomnano(self, **kwargs):
        """Initialize and solve the heterogeneity analysis of bimetallic nanoparticles using coordination numbers obtained from XAS analysis.

        Args:
            **kwargs: Keyword arguments for the input dictionary

        Examples:
            >>> dn = DecomNano()
            >>> dn.calc_decomnano(RPt=2.77, RAu=2.88, fAu=0.2, nAuAu=6.5, nPtPt=9.9, nAuPt=0.6, nPtAu=1.13, DA=0, DAP=18, DP=5)
        """
        self.input.update(**kwargs)
        # if self.check_duplicate_input():
        #     return

        self.solve_decomnano()

    def print_input(self):
        print(self.input)

    def solve_decomnano(self):
        result = self.session.evaluate(
            wlexpr(self.decomnano_equation.format(**self.input))
        )

        df = pd.DataFrame(result, columns=self.column)
        self.results = pd.concat([self.results, df])

    def check_duplicate_input(self):
        if len(self.results) == 0:
            return False

        input_df = pd.Series(self.input)
        input_columns = input_df.index

        df = self.results[input_columns] == input_df
        df = df.all(axis=1)
        df = df.any()

        if df:
            return True
        else:
            return False

    def convert_dict(self, result):
        dict_list = re.findall(self.dict_regex, str(result))
        dict_list = dict(dict_list)
        return dict_list

    def print_results(self):
        print(self.results)

    def save_results(self, filename="results.csv"):
        self.results.to_csv(filename, index=False)

    def load_results(self, filename="results.csv"):
        if not os.path.exists(filename):
            return
        self.results = pd.read_csv(filename)

    def terminate(self):
        self.session.terminate()

    # mathematica equation for solving the decomnano problem
    header_equation = 'SetDirectory[NotebookDirectory[]];Get["DecomNano.wl"]'
    decomnano_equation = "DecomNano[{RPt}, {RAu}, {fAu}, {nAuAu}, {nPtPt}, {nAuPt}, {nPtAu}, {DA}, {DAP}, {DP}]"


def main():
    dn = DecomNano()
    # dn.load_results()

    input = dict(
        RPt=2.77,
        RAu=2.88,
        fAu=0.2,
        nAuAu=6.5,
        nPtPt=9.9,
        nAuPt=0.6,
        nPtAu=1.13,
        DA=0,
        DAP=18,
        DP=5,
    )

    input_default = dict(
        RPt=2.77,
        RAu=2.88,
        fAu=0.2,
        nAuAu=6.5,
        nPtPt=9.9,
        nAuPt=0.6,
        nPtAu=1.13,
        DA=range(0, 11, 1),
        DAP=[18],
        DP=[18],
    )

    input_range = dict(
        nAuAu=0.5,
        nPtPt=0.7,
        nAuPt=0.5,
        nPtAu=0.8,
    )

    for nAuAu in np.round(
        np.arange(
            input_default["nAuAu"] - input_range["nAuAu"],
            input_default["nAuAu"] + input_range["nAuAu"] + 0.1,
            0.1,
        ),
        decimals=2,
    ):
        input["nAuAu"] = nAuAu
        for nPtPt in np.round(
            np.arange(
                input_default["nPtPt"] - input_range["nPtPt"],
                input_default["nPtPt"] + input_range["nPtPt"] + 0.1,
                0.1,
            ),
            decimals=2,
        ):
            input["nPtPt"] = nPtPt
            for nAuPt in np.round(
                np.arange(
                    input_default["nAuPt"] - input_range["nAuPt"],
                    input_default["nAuPt"] + input_range["nAuPt"] + 0.1,
                    0.1,
                ),
                decimals=2,
            ):
                input["nAuPt"] = nAuPt
                for nPtAu in np.round(
                    np.arange(
                        input_default["nPtAu"] - input_range["nPtAu"],
                        input_default["nPtAu"] + input_range["nPtAu"] + 0.1,
                        0.1,
                    ),
                    decimals=2,
                ):
                    input["nPtAu"] = nPtAu

                    for DAP in input_default["DAP"]:
                        input["DAP"] = DAP
                        for DA in input_default["DA"]:
                            input["DA"] = DA
                            for DP in input_default["DP"]:
                                input["DP"] = DP

                                dn.calc_decomnano(**input)
                dn.print_input()
                dn.save_results()
