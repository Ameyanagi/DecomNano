=====
Usage
=====

To use DecomNano in a project::

    import decomnano
