"""Top-level package for DecomNano."""

__author__ = """Ryuichi Shimogawa"""
__email__ = 'ryuichi.shimogawa@stonybrook.edu'
__version__ = '0.1.0'
