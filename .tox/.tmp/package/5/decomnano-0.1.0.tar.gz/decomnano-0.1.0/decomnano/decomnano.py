"""Main module."""


def print_abc():
    """Prints abc."""
    print("abc")

    return 0
