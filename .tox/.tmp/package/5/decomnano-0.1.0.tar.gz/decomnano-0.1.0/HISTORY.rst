=======
History
=======

0.1.0 (2023-04-23)
------------------

* First release on PyPI.
